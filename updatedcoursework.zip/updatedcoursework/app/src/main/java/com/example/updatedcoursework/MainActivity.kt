package com.example.updatedcoursework

import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.*

class MainActivity : AppCompatActivity() {

    // These are the items on the screen
    private lateinit var etTask: EditText
    private lateinit var btnAdd: Button
    private lateinit var lvTasks: ListView
    private lateinit var progressBar: ProgressBar
    private lateinit var tvStatus: TextView

    // Firebase connection and task list
    private lateinit var database: DatabaseReference
    private val taskList = mutableListOf<Task>()
    private lateinit var adapter: ArrayAdapter<Task>
    private var selectedTaskId: String? = null // Used when editing a task

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Link UI items to the code
        etTask = findViewById(R.id.etTask)
        btnAdd = findViewById(R.id.btnAdd)
        lvTasks = findViewById(R.id.lvTasks)
        progressBar = findViewById(R.id.progressBar)
        tvStatus = findViewById(R.id.tvStatus)

        // Connect to Firebase "tasks" section
        database = FirebaseDatabase.getInstance().getReference("tasks")

        // Set up list to show tasks
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, taskList)
        lvTasks.adapter = adapter

        // What happens when "Add" button is clicked
        btnAdd.setOnClickListener {
            if (selectedTaskId == null) {
                createTask() // Add new task
            } else {
                updateTask() // Update selected task
            }
        }

        // When user clicks on a task in the list (to edit)
        lvTasks.setOnItemClickListener { _, _, position, _ ->
            val task = taskList[position]
            etTask.setText(task.name)
            selectedTaskId = task.id
            btnAdd.text = "Update"
            tvStatus.text = "Editing task..."
        }

        // When user holds (long press) a task (to delete)
        lvTasks.setOnItemLongClickListener { _, _, position, _ ->
            showDeleteDialog(taskList[position].id)
            true
        }

        // Start by loading all tasks
        loadTasks()
    }

    // Load tasks from Firebase and show them in the list
    private fun loadTasks() {
        showLoading(true)
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                taskList.clear()
                // Add each task from the database into the list
                snapshot.children.mapNotNullTo(taskList) {
                    it.getValue(Task::class.java)
                }
                adapter.notifyDataSetChanged()
                showLoading(false)
                updateStatus() // Show how many tasks we have
            }

            override fun onCancelled(error: DatabaseError) {
                showLoading(false)
                tvStatus.text = "Error loading tasks"
                Toast.makeText(this@MainActivity, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    // Create a new task and save to Firebase
    private fun createTask() {
        val taskText = etTask.text.toString().trim()
        if (taskText.isEmpty()) {
            etTask.error = "Task cannot be empty"
            return
        }

        showLoading(true)
        val taskId = database.push().key
        if (taskId != null) {
            val task = Task(taskId, taskText, false)
            database.child(taskId).setValue(task)
                .addOnSuccessListener {
                    resetForm()
                    showToast("Task added")
                }
                .addOnFailureListener {
                    Log.e("FIREBASE_ERROR", "Add failed", it)
                    showToast("Failed to add task")
                }
                .addOnCompleteListener {
                    showLoading(false)
                }
        }
    }

    // Update an existing task in Firebase
    private fun updateTask() {
        val taskText = etTask.text.toString().trim()
        if (taskText.isEmpty()) {
            etTask.error = "Task cannot be empty"
            return
        }

        selectedTaskId?.let { taskId ->
            showLoading(true)
            database.child(taskId).child("name").setValue(taskText)
                .addOnSuccessListener {
                    resetForm()
                    showToast("Task updated")
                }
                .addOnFailureListener {
                    showToast("Failed to update task")
                }
                .addOnCompleteListener {
                    showLoading(false)
                }
        }
    }

    // Ask the user if they really want to delete the task
    private fun showDeleteDialog(taskId: String) {
        AlertDialog.Builder(this)
            .setTitle("Delete Task")
            .setMessage("Are you sure you want to delete this task?")
            .setPositiveButton("Delete") { _, _ -> deleteTask(taskId) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // Delete a task from Firebase
    private fun deleteTask(taskId: String) {
        showLoading(true)
        database.child(taskId).removeValue()
            .addOnSuccessListener {
                resetForm()
                showToast("Task deleted")
            }
            .addOnFailureListener {
                showToast("Failed to delete task")
            }
            .addOnCompleteListener {
                showLoading(false)
            }
    }

    // Clear the input field and reset button
    private fun resetForm() {
        etTask.text.clear()
        selectedTaskId = null
        btnAdd.text = "Add"
        updateStatus()
    }

    // Show how many tasks are there
    private fun updateStatus() {
        tvStatus.text = "${taskList.size} task(s)"
    }

    // Show or hide the progress bar
    private fun showLoading(isLoading: Boolean) {
        progressBar.visibility = if (isLoading) ProgressBar.VISIBLE else ProgressBar.GONE
    }

    // Show message at bottom of screen
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}

// This is the data format of each task
data class Task(
    val id: String = "",
    val name: String = "",
    val isCompleted: Boolean = false
) {
    // This will be shown in the task list
    override fun toString(): String = name
}
